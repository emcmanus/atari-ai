# atari-ai [![Gitter](http://img.shields.io/:chat-on_gitter-33CC99.svg)](https://gitter.im/Stitchpunk/atari-ai "Join the discussion")
# THIS. GUY. FUCKS.
