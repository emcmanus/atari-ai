from myModule import someTabs

for x in range(100):
	print "BWAHAHAHAHAHAHA"