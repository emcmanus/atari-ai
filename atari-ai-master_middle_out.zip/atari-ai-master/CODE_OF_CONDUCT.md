# Code of Conduct

Respect your fellow programmers and use tabs to indent. Any use of space for indentation shall be punished by Richard Hendricks.
